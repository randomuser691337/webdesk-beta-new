wm.notif("hello", "Hello World!")
